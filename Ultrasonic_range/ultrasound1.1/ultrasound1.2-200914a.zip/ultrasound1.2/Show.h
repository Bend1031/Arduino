#include "system.h"
#define RS_PIN 12
#define EN_PIN 11
#define D4 8
#define D5 7
#define D6 6
#define D7 5

void Show_Init();
void ShowData(unsigned long dis, unsigned long temp);
